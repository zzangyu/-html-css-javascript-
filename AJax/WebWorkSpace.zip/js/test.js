function show() {
    // img 태그에 이미지를 보여주기
     document.getElementById("fig").src="./img/ElvisPresley.png"
  }
  function hide() {
      // img 태그에 있는 이미지를 숨기기
      document.getElementById("fig").src=""
  }